# Assignment #1
> Data Structures Deadline – 2022/10/14

## Requirements

```bash
sudo apt install build-essential
```

## Usage 

```bash
cd HW1_F74104765
g++ main.cpp
./a.out < p1.in > p1.out
cat p1.out
```