# Assignment #4
> Data Structures Deadline – 2022/12/23

## Requirements

```bash
sudo apt install build-essential 
```

make sure your g++ version is 8 or later.

```bash
g++ --version
```

this program require some features in C++20. if you are using Dev-C++, here is a tutorial about set up C++20 support for Dev-C++. 

> https://blog.csdn.net/qq_50285142/article/details/122930647

## Usage 


```bash
cd HW4_F74104765
g++ -std=c++2a dijkstra.cpp
./a.out
g++ -std=c++2a prim.cpp
./a.out
```